// script-main.js

document.addEventListener('DOMContentLoaded', function() {
    console.log("Selamat datang di halaman utama Kenangan Kita!");
});