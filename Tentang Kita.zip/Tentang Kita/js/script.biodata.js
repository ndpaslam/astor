document.addEventListener('DOMContentLoaded', function () {
  // fungsi hitung usia
  function hitungUsia(tanggalLahir) {
    const lahir = new Date(tanggalLahir);
    const sekarang = new Date();
    let usia = sekarang.getFullYear() - lahir.getFullYear();
    const bulan = sekarang.getMonth() - lahir.getMonth();
    if (bulan < 0 || (bulan === 0 && sekarang.getDate() < lahir.getDate())) {
      usia--;
    }
    return usia;
  }

  // pastiin elemen dengan ID-nya ada
  const usiaDip = document.getElementById('usia-dip');
  const usiaBila = document.getElementById('usia-bila');

  if (usiaDip && usiaBila) {
    usiaDip.textContent = hitungUsia('2008-03-04');
    usiaBila.textContent = hitungUsia('2007-04-16'); // udah lu benerin ke 16 April 2007
  } else {
    console.warn("Element ID usia-dip atau usia-bila gak ketemu!");
  }
});